var gulp = require('gulp');
var webserver = require('gulp-webserver');
 
// 启动：本地环境
gulp.task('local', function() {
  gulp.src('./blueair-plus')
    .pipe(webserver({
      livereload: true,
      host: "192.168.168.85",
      open: true,
      port: 8081
    }));
});
 
// 启动：线上环境
gulp.task('remote', function() {
  gulp.src('./blueair-plus_onlive')
    .pipe(webserver({
      livereload: true,
      host: "127.0.0.1",
      open: true,      port: 8888
    }));
});

// 启动：测试环境
gulp.task('demo', function() {
  gulp.src('./blueair-plus-demo')
    .pipe(webserver({
      livereload: true,
      host: "127.0.0.1",
      open: true,
      port: 8082
    }));
});

console.log("启动项目成功。。。。。");