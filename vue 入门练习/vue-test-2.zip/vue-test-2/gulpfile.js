var gulp = require('gulp');
var webserver = require('gulp-webserver');
 
// 启动：本地环境
gulp.task('local', function() {
  gulp.src('./www')
    .pipe(webserver({
      livereload: true,
      host: "127.0.0.1",
      open: true,
      port: 8080
    }));
});

console.log("启动项目成功。。。。。");